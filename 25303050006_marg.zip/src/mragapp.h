#pragma once

// 应用层入口：初始化 llama.cpp、解析命令行并调度建库/问答流程。
int runMragApp(int argc, char *argv[]);
